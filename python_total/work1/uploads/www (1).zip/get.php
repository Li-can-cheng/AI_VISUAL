<?php
session_start();
include 'login_check.php';
include 'mainclass.php';

function loadSessionDatas(array $total):array
{
    $filename = "/tmp/My-NoteBook.txt";
    if (file_exists($filename)) {
        $res = file_get_contents($filename);
        $count = count(explode("|", $res)) - 1;
        for ($i = 0; $i < $count; $i++) {
            $total[$i] = explode("|", $res)[$i];
            if (is_serialized($total[$i])) {
                unserialize($total[$i]);
            }
        }
        return $total;
    } else {
        file_put_contents($filename, '');
        return [];
    }
}

function is_serialized($data):bool{
    $data = trim($data);
    if('N;' == $data)
        return true;
    if(!preg_match('/^([adObis]):/',$data,$options))
        return false;
    switch($options[1]){
        case 'a':
        case 'O':
        case 's':
            if(preg_match( "/^$options[1]:[0-9]+:.*[;}]\$/s", $data))
                return true;
            break;
        case 'b':
        case 'i':
        case 'd':
            if(preg_match("/^$options[1]:[0-9.E-]+;\$/",$data))
                return true;
            break;
    }
    return false;
}

    $context = array();
    $res = loadSessionDatas($context);
    echo json_encode($res);