<?php
session_start();
include 'login_check.php';

function saveSessionData()
{
    $filename = "/tmp/My-NoteBook.txt";
    $data = file_get_contents("php://input");
    file_put_contents($filename,$data."|",FILE_APPEND);
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    saveSessionData();
}else{
    echo "Request Method Not Allowed";
    return;
}