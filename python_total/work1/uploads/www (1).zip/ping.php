<?php
    echo "pong!";
?>