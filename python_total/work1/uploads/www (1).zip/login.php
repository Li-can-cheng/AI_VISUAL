<?php
session_start();
/**
 * @throws Exception
 */
function stringToRandom($length): string
{
    $s = "";
    for ($i=0;$i<$length;$i++){
        $s .= chr(random_int(32,127));
    }
    return $s;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (!isset($_POST['check-code-1']) || !isset($_POST['check-code-2'])){
        return;
    }
    if ($_POST['check-code-1'] == $_POST['check-code-2']){
        die("<script>alert('The checkcodes cannot be equalled or empty!')</script>");
    }
    if (md5($_POST['check-code-1']) == md5($_POST['check-code-2'])){
        $_SESSION['username'] = 'admin';
        $_SESSION['session_id'] = md5(stringToRandom(16));
        header("Location:index.php");
    }else{
        die("<script>alert('The md5 of two checkcodes should be equalled!')</script>");
    }
}
?>

<html>
    <head>
        <title>My Notebook</title>
        <meta charset="utf-8">
        <meta name="author" content="R1esbyfe">
        <meta name="keywords" content="Challenge08">
        <link href="static/login.css" rel="stylesheet">
    </head>
    <body>
        <form action="./login.php" method="POST">
            <p>Try to input something to be admin!</p>
            <p>Only admin can get into my notebook!</p>
            <div class="form-style">
                <label for="check-code-1">CHCEKCODE1</label>
                <input type="text" name="check-code-1" id="check-code-1">
            </div>
            <div class="form-style">
                <label for="check-code-2">CHECKCODE2</label>
                <input type="text" name="check-code-2" id="check-code-2">
            </div>
            <div class="button">
                <button type="submit">CHECK</button>
            </div>
        </form>
    </body>
    <!--try ./www.zip to find some source code???-->
</html>
