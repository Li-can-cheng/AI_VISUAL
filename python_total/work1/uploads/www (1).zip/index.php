<?php
    session_start();
    include 'login_check.php';
?>

<html>
    <head>
        <title>My Notebook</title>
        <meta charset="utf-8">
        <meta name="author" content="R1esbyfe">
        <meta name="keywords" content="Challenge08">
        <link href="static/style.css" rel="stylesheet">
    </head>
<body>
    <div>
        <h1>Create your notes</h1>
        <form action="index.php" method="post">
            <label for="value"><input type="text" name="value" id="value" placeholder="input your note here"></label>
            <button id="save" type="button">Add Your Notes!</button>
        </form>
        <ol id="notelist"></ol>
    </div>
    <script>
        const val = document.getElementById('value')
        const save = document.getElementById('save')
        const notelist = document.getElementById('notelist')

        save.onclick = async e => {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function (){
                if(xhr.readyState == 4){
                    document.getElementById('value').value = "";
                    setTimeout(`location.reload()`,1000);
                }
            }
            xhr.open('POST','./save.php',true)
            xhr.send(val.value)
        }

        async function fresh() {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function (){
                if(xhr.readyState == 4){
                    var info = xhr.responseText;
                    var res = "";
                        info = JSON.parse(info);
                        for(var i=0; i<info.length; i++){
                            res += "<li><span>"+info[i]+"</span></li>";
                        }
                    document.getElementById('notelist').innerHTML = "";
                    notelist.innerHTML += res;
                }
            }
            xhr.open('GET','./get.php',true)
            xhr.send(null)
        }

        window.onload = e => {
            fresh()
        }
    </script>
</body>
</html>
