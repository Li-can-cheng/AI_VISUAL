<?php
class HereWeGo{
    public $try;
    public function __destruct(){
        $this->try->gogogo();
    }
}

class GoGoGo{
    public $go;

    public function __construct($go)
    {
        $this->go = $go;
    }

    public function __call($name,$arguments){
        return $this->go->web;
    }
}

class Evil{
    public $file;
    public $final;

    public function __construct($file){
        $this->file = $file;
    }
    //The flag is in /flag
    public function __get($Attribute){
        $result = file_get_contents($this->file);
        if(preg_match('/vidar/i',$result)){
            $this->final = "HACKER!!!";
            file_put_contents('flag.txt',$this->final);
            return;
        }
        $this->final = $result;
        file_put_contents('flag.txt',$this->final);
    }
}









